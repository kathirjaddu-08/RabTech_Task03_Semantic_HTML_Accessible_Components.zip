# RabTech Academy – Task 03

## Semantic HTML5 & Accessible Component Architecture

This project provides a clean, setup-ready enterprise dashboard prototype based on the task requirements.

### Included
- Multi-page accessible layout
- Header, navigation, sidebar, main content, sections, articles and footer
- Semantic HTML5 elements
- Accessible data table with caption and scoped headers
- Accessible form controls with labels, fieldset, legend and validation
- Keyboard-visible focus states
- Skip-to-content link
- Accessible status messages using `aria-live`
- Accessible modal dialog example

## Files

```text
RabTech_Task03_Semantic_HTML_Accessible_Components/
├── index.html
├── components.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
└── README.md
```

## Run locally

Open `index.html` in a modern browser.

## Validation

Before submission, run both pages through the W3C HTML Validator and confirm zero errors. Also test keyboard navigation with Tab, Shift+Tab, Enter, Space and Escape.

The code in this package is intentionally kept free of invented validation results; attach your actual validator evidence if RabTech requests screenshots.
