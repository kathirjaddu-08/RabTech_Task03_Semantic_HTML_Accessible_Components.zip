const form = document.querySelector("#contact-form");
const status = document.querySelector("#form-status");

if (form && status) {
  form.addEventListener("submit", (event) => {
    event.preventDefault();

    if (!form.checkValidity()) {
      status.textContent = "Please complete all required fields correctly.";
      return;
    }

    status.textContent = "Message submitted successfully.";
    form.reset();
  });
}

const demoButton = document.querySelector("#demo-button");
const buttonStatus = document.querySelector("#button-status");

if (demoButton && buttonStatus) {
  demoButton.addEventListener("click", () => {
    buttonStatus.textContent = "Button activated.";
  });
}

const dialog = document.querySelector("#demo-dialog");
const openDialog = document.querySelector("#open-dialog");
const closeDialog = document.querySelector("#close-dialog");

if (dialog && openDialog && closeDialog) {
  openDialog.addEventListener("click", () => dialog.showModal());
  closeDialog.addEventListener("click", () => dialog.close());
}
